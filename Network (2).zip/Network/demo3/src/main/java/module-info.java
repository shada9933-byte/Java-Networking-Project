module org.example.demo3 {

    requires javafx.controls;
    requires javafx.web;
    exports org.example.demo3;
    requires java.rmi;
    opens org.example.demo3 to java.rmi;
}

