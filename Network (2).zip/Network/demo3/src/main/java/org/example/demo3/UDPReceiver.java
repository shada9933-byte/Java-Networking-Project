package org.example.demo3;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class UDPReceiver {

    public static void main(String[] args) {

        int port = 5000;

        try (DatagramSocket socket =
                     new DatagramSocket(port)) {

            System.out.println(
                    "UDP Receiver started on port " + port);

            byte[] buffer = new byte[1024];

            while (true) {

                DatagramPacket packet =
                        new DatagramPacket(
                                buffer,
                                buffer.length);

                socket.receive(packet);

                String message =
                        new String(
                                packet.getData(),
                                0,
                                packet.getLength());

                if (message.equals("EOF")) {
                    break;
                }

                System.out.println(message);
            }

            System.out.println("File transfer completed.");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
}