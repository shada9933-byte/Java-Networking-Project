package org.example.demo3;

import java.io.BufferedReader;
import java.io.FileReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class UDPSender {

    public static void main(String[] args) {

        String fileName = "message.txt";
        String receiverAddress = "localhost";
        int port = 5000;

        try (
                BufferedReader reader =
                        new BufferedReader(
                                new FileReader(fileName));

                DatagramSocket socket =
                        new DatagramSocket()
        ) {

            InetAddress address =
                    InetAddress.getByName(receiverAddress);

            String line;
            int lineNumber = 1;

            while ((line = reader.readLine()) != null) {

                byte[] data = line.getBytes();

                DatagramPacket packet =
                        new DatagramPacket(
                                data,
                                data.length,
                                address,
                                port);

                socket.send(packet);

                System.out.println(
                        "Sent line " + lineNumber + ": " + line);

                lineNumber++;

                Thread.sleep(200);
            }

            // EOF marker
            String endMessage = "EOF";

            byte[] endData = endMessage.getBytes();

            DatagramPacket endPacket =
                    new DatagramPacket(
                            endData,
                            endData.length,
                            address,
                            port);

            socket.send(endPacket);

            System.out.println(
                    "File sent successfully.");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
}