package org.example.demo3;

import java.rmi.Naming;

public class Calc {

    public static void main(String[] args) {

        if (args.length != 3) {
            System.out.println("Usage: java Calc <operand1> <operator> <operand2>");
            return;
        }

        try {

            int operand1 = Integer.parseInt(args[0]);
            String operator = args[1];
            int operand2 = Integer.parseInt(args[2]);

            Calculator calculator =
                    (Calculator) Naming.lookup("rmi://localhost/Calculator");

            int result;

            switch (operator) {

                case "+":
                    result = calculator.add(operand1, operand2);
                    break;

                case "-":
                    result = calculator.subtract(operand1, operand2);
                    break;

                case "*":
                    result = calculator.multiply(operand1, operand2);
                    break;

                case "/":
                    if (operand2 == 0) {
                        System.out.println("Error: Cannot divide by zero.");
                        return;
                    }

                    result = calculator.divide(operand1, operand2);
                    break;

                default:
                    System.out.println("Invalid operator!");
                    return;
            }

            System.out.println(
                    operand1 + " " + operator + " " + operand2 + " = " + result
            );

        } catch (NumberFormatException e) {

            System.out.println("Error: Operands must be numbers.");

        } catch (Exception e) {

            System.out.println("Error: " + e.getMessage());
        }
    }
}
