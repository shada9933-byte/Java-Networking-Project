package org.example.demo3;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class ChatServer {

    private static final int PORT = 5000;

    private static final List<ClientHandler> clients =
            new CopyOnWriteArrayList<>();

    public static void main(String[] args) {

        try (ServerSocket serverSocket =
                     new ServerSocket(PORT)) {

            System.out.println(
                    "Chat Server started on port " + PORT);

            while (true) {

                Socket socket =
                        serverSocket.accept();

                System.out.println(
                        "New client connected!");

                ClientHandler clientHandler =
                        new ClientHandler(socket, clients);

                clients.add(clientHandler);

                Thread thread =
                        new Thread(clientHandler);

                thread.start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}