package org.example.demo3;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class HTTPWebView extends Application {

    @Override
    public void start(Stage stage) {

        // URL input
        TextField urlField =
                new TextField("https://www.example.com");

        // Load button
        Button loadButton =
                new Button("Load Website");

        // Area for HTTP headers
        TextArea headerArea =
                new TextArea();

        headerArea.setEditable(false);

        // WebView for displaying the website
        WebView webView =
                new WebView();

        // Button action
        loadButton.setOnAction(event -> {

            String urlText =
                    urlField.getText();

            try {

                // Create URL
                URL url =
                        new URL(urlText);

                // Open connection
                HttpURLConnection connection =
                        (HttpURLConnection) url.openConnection();

                connection.setRequestMethod("GET");

                connection.connect();

                // Get HTTP information
                int statusCode =
                        connection.getResponseCode();

                String statusMessage =
                        connection.getResponseMessage();

                String contentType =
                        connection.getContentType();

                long contentLength =
                        connection.getContentLengthLong();

                String server =
                        connection.getHeaderField("Server");

                String date =
                        connection.getHeaderField("Date");

                // Display HTTP headers
                headerArea.setText(
                        "Status: " + statusCode + " "
                                + statusMessage + "\n"
                                + "Content-Type: " + contentType + "\n"
                                + "Content-Length: " + contentLength + "\n"
                                + "Server: " + server + "\n"
                                + "Date: " + date
                );

                // Read HTML content
                InputStream inputStream =
                        connection.getInputStream();

                Scanner scanner =
                        new Scanner(inputStream);

                StringBuilder html =
                        new StringBuilder();

                while (scanner.hasNextLine()) {

                    html.append(scanner.nextLine())
                            .append("\n");
                }

                scanner.close();

                // Display HTML inside WebView
                webView.getEngine()
                        .loadContent(html.toString());

                connection.disconnect();

            } catch (Exception e) {

                headerArea.setText(
                        "Error: " + e.getMessage());

                e.printStackTrace();
            }
        });

        // Layout
        VBox top =
                new VBox(
                        10,
                        new Label("Enter Website URL:"),
                        urlField,
                        loadButton,
                        new Label("HTTP Header Information:"),
                        headerArea
                );

        BorderPane root =
                new BorderPane();

        root.setTop(top);

        root.setCenter(webView);

        // Scene
        Scene scene =
                new Scene(root, 1000, 700);

        stage.setTitle(
                "HTTP Header & Page Content");

        stage.setScene(scene);

        stage.show();
    }

    public static void main(String[] args) {

        launch();
    }
}