package org.example.demo3;

public class Launcher {

    public static void main(String[] args) {
        HTTPWebView.main(args);
    }
}