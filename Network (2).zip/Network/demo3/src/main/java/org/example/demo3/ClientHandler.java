package org.example.demo3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;

public class ClientHandler implements Runnable {

    private Socket socket;
    private List<ClientHandler> clients;

    private BufferedReader input;
    private PrintWriter output;

    public ClientHandler(Socket socket,
                         List<ClientHandler> clients) {

        this.socket = socket;
        this.clients = clients;

        try {

            input = new BufferedReader(
                    new InputStreamReader(
                            socket.getInputStream()));

            output = new PrintWriter(
                    socket.getOutputStream(),
                    true);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {

        try {

            // Receive client's name
            String username = input.readLine();

            String message;

            while ((message = input.readLine()) != null) {

                // Exit command
                if (message.equalsIgnoreCase("/exit")) {
                    break;
                }

                System.out.println(
                        username + ": " + message);

                // Broadcast message to all clients
                broadcast(username + ": " + message);
            }

        } catch (IOException e) {

            System.out.println("Client disconnected.");

        } finally {

            clients.remove(this);

            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

            System.out.println("Client removed.");
        }
    }

    private void broadcast(String message) {

        for (ClientHandler client : clients) {

            client.output.println(message);
        }
    }
}