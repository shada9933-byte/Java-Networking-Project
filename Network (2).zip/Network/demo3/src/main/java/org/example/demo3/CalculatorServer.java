package org.example.demo3;
import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class CalculatorServer {

    public static void main(String[] args) {

        try {
            LocateRegistry.createRegistry(1099);

            Calculator calculator = new CalculatorImpl();

            Naming.rebind("rmi://localhost/Calculator", calculator);

            System.out.println("Calculator Server is running...");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
