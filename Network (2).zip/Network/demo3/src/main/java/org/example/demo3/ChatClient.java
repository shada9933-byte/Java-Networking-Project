package org.example.demo3;
import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class ChatClient {

    public static void main(String[] args) {

        try {

            Socket socket =
                    new Socket("localhost", 5000);

            BufferedReader input =
                    new BufferedReader(
                            new InputStreamReader(
                                    socket.getInputStream()));

            PrintWriter output =
                    new PrintWriter(
                            socket.getOutputStream(),
                            true);

            Scanner scanner =
                    new Scanner(System.in);

            System.out.print("Enter your name: ");
            String username = scanner.nextLine();

            // Send username to server
            output.println(username);

            System.out.println(
                    "Connected to server!");

            // Thread for receiving messages
            Thread receiver = new Thread(() -> {

                try {

                    String message;

                    while ((message = input.readLine()) != null) {

                        System.out.println(message);
                    }

                } catch (IOException e) {

                    System.out.println(
                            "Disconnected from server.");
                }
            });

            receiver.start();

            // Send messages
            while (true) {

                String message =
                        scanner.nextLine();

                output.println(message);

                if (message.equalsIgnoreCase("/exit")) {
                    break;
                }
            }

            socket.close();
            scanner.close();

            System.out.println("Disconnected.");

        } catch (IOException e) {

            e.printStackTrace();
        }
    }
}